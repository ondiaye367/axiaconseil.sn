# Skill /yt-search — Specs finales

## Mode

Recherche YouTube par mots-cles (mode 1/2).

## Usage

```
/yt-search "python tutorial"
```

## Comportement

- Recherche via `yt-dlp` en mode flat (`ytsearch10:<query>` + `--flat-playlist --dump-json`)
- Retourne un tableau markdown de 10 resultats max
- Rapide (~5-10s, pas de requete individuelle par video)
- Timeout de 30 secondes avec gestion d'erreur

## Colonnes du tableau

| # | Titre | URL | Chaine | Vues | Duree |
|---|-------|-----|--------|------|-------|

- Vues formatees avec separateurs (ex: 1 234 567)
- Durees formatees en HH:MM:SS ou MM:SS
- URLs au format `https://www.youtube.com/watch?v=<id>`

## Structure des fichiers

```
CCNLM/
└── .claude/skills/yt-search/
    ├── SKILL.md                  <- Skill complet (frontmatter + instructions + examples + troubleshooting)
    └── scripts/
        └── yt_search.py          <- Script Python (yt-dlp, ~180 lignes)
```

Le script est bundle dans le dossier du skill (pas a la racine du projet), conformement au guide officiel Anthropic.

## SKILL.md — Contenu

- **Frontmatter** : name, description (WHAT + WHEN + trigger phrases), allowed-tools, metadata
- **Instructions** : 4 etapes (extraire query, executer script, afficher resultats, gestion erreurs)
- **Examples** : 3 cas (recherche simple, francais, sans argument)
- **Troubleshooting** : 4 erreurs courantes avec causes et solutions

## Limites

- Pas de likes/commentaires (indisponibles en mode flat)
- Pas de date de publication (indisponible en mode flat)
- Region/langue : defaut yt-dlp
- Tri : relevance (defaut YouTube)

## Mode 2 (a venir)

Tendances YouTube — sera implemente separement.
