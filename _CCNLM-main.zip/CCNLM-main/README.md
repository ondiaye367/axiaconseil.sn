# CCNLM — Claude Code + NotebookLM YouTube Workflow

Workflow automatise pour rechercher des videos YouTube et generer du contenu (podcasts, briefings, etc.) via Google NotebookLM, le tout pilote depuis Claude Code.

## Prerequis

- **Python 3.10+** — `python3 --version`
- **Claude Code** (CLI Anthropic) — [Installation officielle](https://docs.anthropic.com/en/docs/claude-code/overview)
- **pip3** — `pip3 --version`

## 1. Installation de yt-dlp

[yt-dlp](https://github.com/yt-dlp/yt-dlp) est un outil en ligne de commande pour extraire des donnees YouTube.

```bash
pip3 install yt-dlp
```

Verification :

```bash
yt-dlp --version
```

Mise a jour (a faire regulierement, YouTube change souvent son API interne) :

```bash
pip3 install -U yt-dlp
```

### Ce que fait le script `yt_search.py`

Le script utilise yt-dlp en mode **flat-playlist** (`ytsearch10:<query> --flat-playlist --dump-json`) pour rechercher 10 videos YouTube correspondant aux mots-cles fournis. Ce mode est rapide (~5-10s) car il ne telecharge pas les metadonnees completes de chaque video.

Donnees retournees : titre, URL, chaine, nombre de vues, duree.
Non disponible en mode flat : likes, commentaires, date de publication.

## 2. Skills et Commands Claude Code

### Structure du projet

```
CCNLM/
├── .claude/
│   ├── commands/
│   │   └── yt-search.md              # Commande slash /yt-search
│   └── skills/
│       └── yt-search/
│           ├── SKILL.md              # Definition du skill (instructions, exemples, troubleshooting)
│           └── scripts/
│               └── yt_search.py      # Script Python (~200 lignes)
├── guide/
│   └── The-Complete-Guide-to-Building-Skill-for-Claude.pdf
└── README.md
```

### Comment ca marche

- **`.claude/commands/yt-search.md`** — Definit la commande slash `/yt-search` que l'on tape dans Claude Code. Elle appelle le script Python avec les mots-cles fournis.
- **`.claude/skills/yt-search/SKILL.md`** — Contient les instructions completes du skill : quand l'activer, comment l'executer, gestion des erreurs, exemples.
- **`.claude/skills/yt-search/scripts/yt_search.py`** — Le script Python qui fait la recherche via yt-dlp et formate les resultats.

### Mise en place

Les skills et commands sont automatiquement detectes par Claude Code quand on travaille depuis le repertoire du projet :

```bash
cd /chemin/vers/CCNLM
claude   # Lancer Claude Code depuis ce repertoire
```

Si vous clonez le repo, les skills sont disponibles immediatement — aucune configuration supplementaire.

### Usage

```
/yt-search "machine learning basics"
```

Retourne une liste formatee de 10 videos avec URLs pretes a copier.

## 3. Installation de notebooklm-py

[notebooklm-py](https://github.com/teng-lin/notebooklm-py) (par Teng Li) est un CLI et SDK Python pour Google NotebookLM.

### Installation

```bash
pip install notebooklm-py
```

### Installation du skill Claude Code

```bash
notebooklm skill install
```

Cela installe le skill `/notebooklm` dans Claude Code pour piloter NotebookLM directement depuis le chat.

### Authentification Google

```bash
notebooklm login
```

Ouvre le navigateur pour l'authentification OAuth Google. Necessaire une seule fois (le token est sauvegarde localement).

### Verification

```bash
notebooklm list
```

Affiche la liste de vos notebooks existants. Si ca fonctionne, l'authentification est OK.

### Commandes essentielles

| Commande | Description |
|----------|-------------|
| `notebooklm create "Nom"` | Creer un nouveau notebook |
| `notebooklm source add <notebook_id> --youtube <url>` | Ajouter une video YouTube comme source |
| `notebooklm generate podcast <notebook_id>` | Generer un podcast audio |
| `notebooklm generate briefing <notebook_id>` | Generer un briefing document |
| `notebooklm list` | Lister tous les notebooks |

Consulter `notebooklm --help` pour la liste complete des commandes.

## 4. Workflow complet (exemple)

### Etape 1 : Rechercher des videos YouTube

Dans Claude Code, lancer :

```
/yt-search "artificial intelligence 2025"
```

Resultat : une liste de 10 videos avec leurs URLs.

### Etape 2 : Creer un notebook et generer du contenu

Utiliser le skill `/notebooklm` dans Claude Code :

```
/notebooklm
```

Puis demander a Claude de :
1. Creer un nouveau notebook
2. Ajouter les URLs YouTube obtenues a l'etape 1 comme sources
3. Generer un podcast (ou un briefing, un guide d'etude, etc.)

Claude pilote notebooklm-py pour executer ces actions automatiquement.

### Resultat

Un podcast audio (ou autre format) genere par NotebookLM a partir du contenu des videos YouTube selectionnees — le tout sans quitter Claude Code.
